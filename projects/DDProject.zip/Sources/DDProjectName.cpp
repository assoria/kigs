#include <DDProjectName.h>
#include <FilePathManager.h>
#include <NotificationCenter.h>


IMPLEMENT_CLASS_INFO(DDProjectName);

IMPLEMENT_CONSTRUCTOR(DDProjectName)
{

}

void	DDProjectName::ProtectedInit()
{
	// Base modules have been created at this point

	// lets say that the update will sleep 1ms
	SetUpdateSleepTime(1);

	SP<FilePathManager>& pathManager = KigsCore::Singleton<FilePathManager>();
	pathManager->AddToPath(".", "xml");


	// Load AppInit, GlobalConfig then launch first sequence
	DataDrivenBaseApplication::ProtectedInit();
}

void	DDProjectName::ProtectedUpdate()
{
	DataDrivenBaseApplication::ProtectedUpdate();
}

void	DDProjectName::ProtectedClose()
{
	DataDrivenBaseApplication::ProtectedClose();
}

void	DDProjectName::ProtectedInitSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{

	}
}
void	DDProjectName::ProtectedCloseSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{
		
	}
}

