import com.kigs.kigsmain.kigsmainActivity;


// empty
public class DDProjectNameEmpty {
	
	
}
